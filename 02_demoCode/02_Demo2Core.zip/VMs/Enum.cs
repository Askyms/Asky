using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


using Asky;

namespace Asky
{
    /// <summary>
    /// 角色
    /// </summary>
    public enum ERole
    {
        /// <summary>
        /// 1 普通用户
        /// </summary> 
        User  = 1,

        /// <summary>
        /// 2 VIP用户
        /// </summary> 
        Vip = 2
    }

}


