using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;



using Asky;

namespace Asky
{
    public class UserController : Controller
    {
        // /user/AddUserByEmail?email=a1@a.com&pwd=123
        public async Task<string> AddUserByEmail(string email, string pwd)
        {
            return await UserBll.AddUserByEmail(email, pwd);
        }

        // /user/LoginByEmail?email=a1@a.com&pwd=123
        /// <summary>
        /// 邮箱用户登录验证
        /// </summary>
        public async Task<string> LoginByEmail(string email, string pwd)
        {
            return (await UserBll.LoginByEmail(email, pwd)).ToJson();
        }

        // /user/logout
        /// <summary>
        /// 用户退出
        /// </summary>
        public async Task<string> Logout(string returnUrl)
        {
            var cookieValue = ToolA.GetCookie(Config.UserToken);
            var result = await UserBll.Logout(cookieValue);
            UserBll.RedirectToReturnUrl(returnUrl); //跳转到returnUrl或默认首页
            return result;
        }

        // /user/Info
        /// <summary>
        /// 用户有权限才能访问
        /// </summary>
        public async Task<string> Info()
        {
            var vm = Power.HasPower(ERole.Vip); //权限验证
            if (vm.status != Code.SuccessInt) return vm.msg;

            await Task.FromResult("test");
            var tip = "有权限才能访问的内容";
            return tip;
        }

    }
}