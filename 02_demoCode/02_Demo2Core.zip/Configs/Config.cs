using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using System.Text;

using Dapper;

using Asky;

namespace Asky
{

    public partial class Config
    {
        #region a.config配置节点，防止.NET 4.7.x下载json文件风险    

        public static string Demo5 = AppConfig.Config.Demo5; //自定义配置节点dynamic转string        
        public static string LogPath = AppConfig.Config.LogPath;
        public static bool IsDebug = AppConfig.Config.IsDebug == "1";
        public static string MySqlConn = AppConfig.Config.MySqlConn; //TiDB、MySql/MariaDB连接串
        public static string PostgreSqlConn = AppConfig.Config.PostgreSqlConn; //PostgreSql连接串
        /// <summary>
        /// 每天一次任务，是否现在立即执行，用于测试运行，1立即运行，0默认
        /// </summary>
        public static bool TimeTaskDayOnceRunNowTest = AppConfig.Config.TimeTaskDayOnceRunNowTest == "1";
        /// <summary>
        /// 每天几点执行一次任务，默认值凌晨1点
        /// </summary>
        public static int TimeTaskDayOnceHour = AppConfig.Config.TimeTaskDayOnceHour;
        /// <summary>
        /// 每N分钟执行一次任务，是否现在立即执行，用于测试运行，1立即运行，0默认
        /// </summary>
        public static bool TimeTaskMinuteRunNowTest = AppConfig.Config.TimeTaskMinuteRunNowTest == "1";
        /// <summary>
        /// 每N分钟执行一次任务，默认值60
        /// </summary>
        public static int TimeTaskMinute = AppConfig.Config.TimeTaskMinute;

        #endregion

        #region 固定值
        /// <summary>
        /// 请求Api接口，5秒自动超时
        /// </summary>
        public static int ApiTimeOutSecond = 5;

        /// <summary>
        /// 当前登录用户Cookie名称UserToken
        /// </summary>
        public const string UserToken = "UserToken";

        /// <summary>
        /// 默认日期1800-1-1
        /// </summary>
        public static DateTime DefaultDate = new DateTime(1800, 1, 1);
        #endregion

        #region 缓存节点拼接Url
        /// <summary>
        /// 接口地址http://AskyEdu.com/home/demo1
        /// </summary>
        // 注意：从数据库缓存读取节点+拼接时，不能用静态变量=赋值方式，报错 Asky.Config..cctor() ，只能用get{return}方式
        // public static string ApiUrl =  RootUrl+ "api/demo1.ashx"; //报错
        // public static string ApiUrl =  demo1+ "api/demo1.ashx"; //这种方式demo1为空值，因为还没赋值
        public static string DemoApiUrl
        {
            get { return RootUrl + "home/demo1"; }
        }
        #endregion          

        #region 数据库配置，工具类
        private static object configLocker = new object();
        private static readonly string _ConfigCacheKey = "Asky_AConfig_List";

        public static void SetValue(string name, string value, string memo)
        {
            if (name.IsNullOrEmpty() || value.IsNullOrEmpty())
                return;

            lock (configLocker)
            {
                var hasVM = GetValueFromDb(name);
                using (var conn = Db.Conn()) //读写
                {
                    if (hasVM.IsNullOrEmpty()) //不存在，则自动插入一条
                    {
                        var sql = "INSERT INTO AConfig (Name, Value, Memo)  VALUES (@name, @value, @memo)";
                        var result = conn.Execute(sql, new { name = name, value = value, memo = memo });
                    }
                    else //已存在，则更新
                    {
                        var sql = "update AConfig SET value=@value where name=@name";
                        var result = conn.Execute(sql, new { name = name, value = value });
                    }
                }
            }

            //刷新缓存
            RefreshConfigCache();
        }

        /// <summary>
        /// 从数据库读取
        /// </summary>
        public static string GetValueFromDb(string name)
        {
            using (var conn = Db.Conn()) //读写
            {
                //var sql = "select top 1 Value from AConfig where name=@name"; 
                var sql = "select Value from AConfig where name=@name" + Tool.SqlPage(); 
                var result = conn.Query(sql, new { name = name }).FirstOrDefault();
                return result;
            }
        }

        /// <summary>
        /// 刷新Config缓存
        /// </summary>
        public static void RefreshConfigCache()
        {
            CacheA.Remove(_ConfigCacheKey);
        }

        /// <summary>
        /// 得到Config数据列表，加缓存60分钟，缓存不存在时，从数据库读取，并加入缓存，
        /// 不能缓存太长时间，防止TM无法及时自动更新缓存
        /// </summary>
        public static List<AConfig> GetConfigListByCache()
        {
            object cache = CacheA.Get(_ConfigCacheKey);
            if (cache != null)
            {
                var list = cache as List<AConfig>;
                return list;
            }

            using (var conn = Db.Conn())
            {
                var sql = "Select Id, Name, Value, Memo From AConfig";
                var list = conn.Query<AConfig>(sql).ToList();
                CacheA.Set(_ConfigCacheKey, list, 60);
                return list;
            }
        }

        /// <summary>
        /// 加缓存，得到一个实体
        /// </summary>
        private static AConfig GetConfigByNameCache(string name)
        {
            var list = GetConfigListByCache();
            var model = list.FirstOrDefault(c => c.Name == name);
            return model;
        }

        /// <summary>
        /// 加缓存，根据name得到value，找不到返回空值Config表
        /// </summary>
        public static string GetConfigValueByNameCache(string name)
        {
            var config = GetConfigByNameCache(name);
            return config == null ? "" : config.Value;
        }

        /// <summary>
        /// 加缓存，根据name得到value，不存在时自动插入一条数据，
        /// </summary>
        public static string GetValue(string name, string defaultValue, string memo)
        {
            var config = GetConfigByNameCache(name);
            if (config == null)
            {
                SetValue(name, defaultValue, memo);
                return defaultValue;
            }
            return config.Value;
        }
        #endregion

        #region 数据库配置节点，已缓存60分钟

        /// <summary>
        /// 根域名例如askyedu.com
        /// </summary>
        public static string RootDomain
        {
            get { return GetValue("RootDomain", "askyedu.com", "根域名例如askyedu.com"); }
        }

        /// <summary>
        /// 根域名路径 http://askyedu.com/ 包含结尾/
        /// </summary>
        public static string RootUrl
        {
            get { return GetValue("RootUrl", "http://askyedu.com/", "根域名路径 http://askyedu.com/ 包含结尾/"); }
        }

        /// <summary>
        /// 用户注册密码拼接guid混淆后加密
        /// </summary>
        public static string PwdGuid
        {
            get { return GetValue("PwdGuid", Guid.NewGuid().ToString(), "用户注册密码拼接guid混淆后加密"); }
        }

        /// <summary>
        /// 用户登录缓存分钟，默认一天60*24分钟
        /// </summary>
        public static int LoginTokenCacheMinute
        {
            get { return GetValue("LoginTokenCacheMinute", (60 * 24).ToString(), "用户登录缓存分钟，默认一天60*24分钟").ToInt(); }
        }

        #endregion
    }
}
