﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Dapper;
using System.Linq;
using Asky;

namespace Asky
{
    public class ProductBll
    {
        /// <summary>
        /// 添加一个商品，Dapper + TiDB或MySql或MariaDB插入，返回标准json
        /// </summary>
        public static async Task<string> AddProduct(string productName)
        {
            using (var conn = Db.Conn())
            {
                var sql = "insert into product (productName) values (@productName)";
                var amount = await conn.ExecuteAsync(sql, new { productName = productName });
                return (amount >0) ? Code.SuccessJson(amount) : Code.FailJson("添加商品失败");
            }
        }

        /// <summary>
        /// 查出数据列表，pageIndex显示第几页，pageSize每页显示几条数据
        /// </summary>
        public static async Task<string> GetProductList(int pageIndex, int pageSize)
        {
            using (var conn = Db.Conn())                
            {                
                var sql = "select id, productName from product p order by id" + Tool.SqlPage(pageIndex, pageSize);
                //ToList() 需要引用命名空间 using System.Linq; 
                var list = (await  conn.QueryAsync<Product>(sql, new { })).ToList();
                //var first = await conn.QueryFirstOrDefaultAsync<User1>(sql, new { });
                //var first = conn.Query<string>(sql).FirstOrDefault();
                //没有查到数据时，不会报错，返回空json值[]
                return list.ToJson();
            }
        }

        /// <summary>
        /// Dapper 删除一条数据，
        /// 删除一条数据，返回影响的行数，tidb、mysql、pg行为一致，
        /// 找到一条或多条数据则返回影响行数为被删除的数据条数，例如1或N，判断结果条数amount>0表示删除成功
        /// </summary>
        public static async Task<string> DeleteProduct(int id)
        {
            using (var conn = Db.Conn())
            {
                var sql = "delete from product where id=@id";
                var amount = await conn.ExecuteAsync(sql, new { id = id });           
                return (amount > 0) ? Code.SuccessJson(amount) : Code.FailJson("删除商品失败");
            }
        }


        /// <summary>
        /// Dapper MySql更新一条数据，返回影响的行数，
        /// a.config数据库连接串参数useAffectedRows=false表示再次更新相同字段值时，也返回影响1或N行，而不是0行
        /// </summary>
        public static async Task<string> UpdateProduct(int id, string productName)
        {         
            using (var conn = Db.Conn())
            {
                var sql = "update product set productName=@productName where id=@id";
                var amount = await conn.ExecuteAsync(sql, new { id = id, productName = productName });
                return (amount > 0) ? Code.SuccessJson(amount) : Code.FailJson("更新商品失败");
            }
        }

    }

}
