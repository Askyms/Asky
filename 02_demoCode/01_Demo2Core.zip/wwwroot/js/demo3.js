﻿
//将message显示在页面上，el: '#a1'对应<div id="a1">中的id值a1
var a1 = new Vue({ el: '#a1', data: { message: 'vue + dnc / .NET Core 2.x' } });

//综合示例 vue 调用dnc后台接口
var a2 = new Vue({
    el: '#a2', //对应<div id="a2">中的id值a2
    data: {
        newProductId: 0, //对应v-model="newProductId"输入框
        newProductName: '', //对应v-model="newProductName"输入框
        result: '', //返回值
        productList: [], //产品列表数据
        pageIndex: 1, //默认值显示第1页
        pageSize: 10, //默认值每页10条
        isShowList: false //默认不显示列表数据
    },
    methods: {
        //插入一条数据
        addProduct: function () {
            var vm = this; //必须这样，后面的字段赋值才能在页面显示{{result}}
            console.log("【vm.newProductName】" + vm.newProductName);
            //流程：从页面输入框得到vm.newProductName，
            //用Post方式提交到后台接口 /Home/AddProduct，得到接口返回值response.data
            var params = new URLSearchParams();
            params.append('productName', vm.newProductName);
            axios.post('/Home/AddProduct', params) //axios是一个js工具类库，用于调用后台接口
                .then(function (response) {
                    vm.result = response.data;  //返回值，赋值给vm.result才能在页面显示，因为this作用域不同，变量多次赋值最后一次生效
                    if (vm.result != null && vm.result.status == 1) {
                        a2.getProductList(); //调用查询列表数据的方法，必须用a2调用，因为vm、this作用域不同
                    }
                }).catch(function (error) { console.log("【操作失败】" + error); });
        },
        //更新一条数据
        updateProduct: function () {
            var vm = this;
            var params = new URLSearchParams();
            params.append('id', vm.newProductId);
            params.append('productName', vm.newProductName);
            axios.post('/Home/updateProduct', params)
                .then(function (response) {
                    //console.log("【response.data】" + response.data); //返回值
                    vm.result = response.data;  //返回值
                    //for循环找到这一条数据，更新ProductName
                    for (var i = 0; i < vm.productList.length; i++) {
                        if (vm.productList[i].Id == vm.newProductId) {
                            vm.productList[i].ProductName = vm.newProductName;
                        }
                    }
                }).catch(function (error) { console.log("【操作失败】" + error); });
        },

        //删除一条数据
        deleteProduct: function (deleteId) {
            var vm = this;
            var params = new URLSearchParams();
            params.append('id', deleteId);
            axios.post('/Home/deleteProduct', params)
                .then(function (response) {
                    vm.result = response.data;  //返回值
                    if (vm.result != null && vm.result.status == 1) {
                        //for循环找到这一条数据进行删除，console.log记录浏览器调试日志，方便排查问题
                        for (var i = 0; i < vm.productList.length; i++) {
                            if (vm.productList[i].Id == deleteId) {
                                console.log("【vm.productList[i].Id】找到匹配元素" + vm.productList[i].Id);
                                vm.productList.splice(i, 1); //删除一个
                            }
                        }
                    }
                }).catch(function (error) { console.log("【操作失败】" + error); });
        },

        //查询列表
        getProductList: function () {
            var vm = this;
            var params = new URLSearchParams();
            params.append('pageIndex', vm.pageIndex);
            params.append('pageSize', vm.pageSize);
            axios.post('/Home/getProductList', params)
                .then(function (response) {   
                    vm.result = response.data;  //返回值
                    vm.isShowList = true; //将默认隐藏的数据列表显示出来
                    vm.productList = response.data;
                    console.log("【vm.productList】" + response.data);
                }).catch(function (error) { console.log("【操作失败】" + error); });
        },

    }
});