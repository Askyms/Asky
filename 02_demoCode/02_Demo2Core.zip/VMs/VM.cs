using System;
using System.Collections.Generic;
using System.Text;

using Asky;

namespace Asky
{   
 
    public class AConfig
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public string Memo { get; set; }
    }
    
    /// <summary>
    /// 用户表user部分字段
    /// </summary>
    public class AUser
    {
        public int Uid { get; set; }
        public string NickName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Pwd { get; set; }

        /// <summary>
        /// 每次登录变化，随机guid
        /// </summary>
        public string LoginToken { get; set; }
    }

    /// <summary>
    /// 当前登录状态VM
    /// </summary>
    public class UserModel
    {
        public int Uid { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string NickName { get; set; }
        /// <summary>
        /// 每次登录变化，随机guid
        /// </summary>
        public string LoginToken { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
    }

}
   