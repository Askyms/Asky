﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Asky
{
    /// <summary>
    /// 返回值VM标准格式Status、Data、Message
    /// </summary>
    public class Result 
    {
        /// <summary>
        /// 返回值状态码：1成功，其它值失败
        /// </summary>
        public int status { get; set; }

        /// <summary>
        /// 返回值数据
        /// </summary>
        public object data { get; set; }

        /// <summary>
        /// 返回值提示文字，例如错误原因
        /// </summary>
        public string msg { get; set; }
        
    }

    /// <summary>
    /// 返回值参数
    /// </summary>
    public class Code
    {
        /// <summary>
        /// 字符串"1"
        /// </summary>
        public static string SuccessText = "1";

        /// <summary>
        /// 返回结果对象，1成功，data为object，去掉vm.Data json多余双引号
        /// </summary>       
        public static Result Success(object data = null)
        {
            int status = 1;
            return new Result { status = status, msg = "成功", data = data ?? string.Empty };
        }

        /// <summary>
        /// 成功Json
        /// </summary>
        public static string SuccessJson(object data = null)
        {
            return Success(data).ToJson();
        }

        /// <summary>
        /// 返回结果对象，默认错误Status为-2，data为数据
        /// </summary>       
        public static Result Fail(object data, string message)
        {
            int status = -2;
            return new Result { status = status, msg = message, data = data };
        }

        /// <summary>
        /// 返回操作失败json
        /// </summary>
        public static string FailJson(object data, string message)
        {
            return Fail(data, message).ToJson();
        }

        /// <summary>
        /// 返回结果对象，默认错误-2
        /// </summary>       
        public static Result Fail(string message)
        {
            int status = -2;
            var data = "";
            return new Result { status = status, msg = message, data = data };
        }

        /// <summary>
        /// 失败json
        /// </summary>
        public static string FailJson(string message)
        {
            return Fail(message).ToJson();
        }

        /// <summary>
        ///  返回结果对象
        /// </summary>
        public static Result Result(int status,object data, string message)
        {            
            return new Result { status = status, msg = message, data = data };
        }

        /// <summary>
        /// 标准格式json
        /// </summary>
        public static string ResultJson(int status, object data, string message)
        {
            return Result(status,  data, message).ToJson();
        }
    }

}


