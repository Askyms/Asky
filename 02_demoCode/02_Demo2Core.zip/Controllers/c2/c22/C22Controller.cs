using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;


using Asky;

namespace Asky
{
    //public class C2Controller : Controller
    //{
    //    public async Task<string> Index()
    //    {
    //        await Task.FromResult("demo");

    //        return "";
    //    }
    //}
}