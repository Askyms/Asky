﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using System.Text;
using Asky;

namespace Asky
{

    public partial class Config
    {
        #region a.config配置节点，防止.NET 4.7.x下载json文件风险    

        public static string Demo5 = AppConfig.Config.Demo5; //自定义配置节点dynamic转string        
        public static string LogPath = AppConfig.Config.LogPath;
        public static bool IsDebug = AppConfig.Config.IsDebug == "1";
        public static string MySqlConn = AppConfig.Config.MySqlConn; //TiDB、MySql/MariaDB连接串
        public static string PostgreSqlConn = AppConfig.Config.PostgreSqlConn; //PostgreSql连接串
        
        #endregion

        /// <summary>
        /// 请求Api接口，5秒自动超时
        /// </summary>
        public static int ApiTimeOutSecond = 5;

        #region 固定值
        /// <summary>
        /// 当前登录用户Cookie名称UserToken
        /// </summary>
        public const string UserToken = "UserToken";

        /// <summary>
        /// 默认日期1800-1-1
        /// </summary>
        public static DateTime DefaultDate = new DateTime(1800, 1, 1);
        #endregion
    }
}
