using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Dapper;
using System.Linq;


using Asky;

namespace Asky
{
    public class UserBll
    {
        #region CurrentUser 当前登录用户
        /// <summary>
        /// 当前登录用户， 未登录时返回null，
        /// cookie已存在，未登录时根据cookie查数据库loginToken如果不存在，自动移除cookie
        /// loginToken数据库存在时，保存到缓存
        /// </summary>
        public static UserModel CurrentUser
        {
            get
            {
                var cookieValue = ToolA.GetCookie(Config.UserToken);
                if (cookieValue.IsNullOrEmpty())
                    return null;

                var userCache = CacheA.Get(cookieValue) as UserModel;  //从缓存取出
                if (userCache == null)
                {
                    //cookie已存在，未登录时根据cookie查数据库loginToken如果不存在，自动移除cookie
                    //loginToken数据库存在时，保存到缓存
                    var vm = GetUserFromDb(cookieValue);
                    if (vm == null)
                        ToolA.RemoveCookie(cookieValue);
                    else
                        CacheA.Set(cookieValue, vm, Config.LoginTokenCacheMinute);
                    return vm;
                }
                return userCache;
            }
        }

        /// <summary>
        /// 根据cookie值loginToken从数据库取一个用户，找不到时返回null
        /// </summary>
        public static UserModel GetUserFromDb(string cookieValue)
        {
            if (cookieValue.IsNullOrEmpty())
                return null;

            try
            {
                using (var conn = Db.Conn())
                {
                    var sql = "select uid,email,mobile,nickname,logintoken from user where logintoken=@logintoken" + Tool.SqlPage();
                    var vm = conn.Query<UserModel>(sql, new { logintoken = cookieValue }).FirstOrDefault();
                    return vm;
                }
            }
            catch (Exception ex) { LogA.AppError("GetUserFromDb" + ex.ToString()); return null; }
        }
        #endregion

        /// <summary>
        /// 用户用邮箱登录，邮箱已自动转小写并去掉首尾空格，
        /// 验证密码正确后，清除上次登录缓存，更新loginToken、登录时间、登录次数，设置cookie、缓存
        /// </summary>
        public static async Task<Result> LoginByEmail(string email, string pwd)
        {
            if (email.IsNullOrEmpty())
                return Code.Fail("email不能为空");
            if (pwd.IsNullOrEmpty())
                return Code.Fail("密码不能为空");
            email = email.Trim().ToLower(); //转小写
            pwd = pwd.Trim(); //去掉首尾空格

            try
            {
                using (var conn = Db.Conn())
                {
                    var sql = "select pwd,uid,email,mobile,nickname,logintoken from user where email=@email" + Tool.SqlPage();
                    var vm = (await conn.QueryAsync<AUser>(sql, new { email = email })).FirstOrDefault();
                    if (vm == null)
                        return Code.Fail("账号或密码错误");

                    var pwdHash = GetPwdHash(pwd); //密码+guid混淆后md5加密
                    if (vm.Pwd != pwdHash)
                        return Code.Fail("账号或密码错误");
                    LogA.Debug("LoginByEmail VM为" + vm.ToJson()); //调试

                    //验证密码正确后，清除上次登录缓存，更新loginToken、登录时间、登录次数，设置cookie、缓存
                    if (!vm.LoginToken.IsNullOrEmpty())
                        CacheA.Remove(vm.LoginToken);  //清除上次登录缓存
                    var logintoken = Guid.NewGuid().ToString(); //每次登录，更新loginToken
                    var now = DateTime.Now;
                    sql = "update user set logintoken=@logintoken, loginamount=loginamount+1, lastlogintime=@now where email=@email";
                    var amount = await conn.ExecuteAsync(sql, new { email = email, logintoken = logintoken, now = now });
                    if (amount > 0)
                    {
                        ToolA.SetCookie(Config.UserToken, logintoken);
                        vm.LoginToken = logintoken; //新loginToken
                        var userModel = GetUserModelByAUser(vm); //vm转换
                        CacheA.Set(logintoken, userModel);
                        return Code.Success("登录成功");
                    }
                    return Code.Fail("账号或密码错误");
                }
            }
            catch (Exception ex) { LogA.AppError("LoginByEmail" + ex.ToString()); return Code.Fail("账号或密码错误，" + ex.Message); }
        }

        /// <summary>
        /// vm转换
        /// </summary>
        public static UserModel GetUserModelByAUser(AUser user)
        {
            if (user == null)
                return null;
            var vm = new UserModel();
            vm.Uid = user.Uid;
            vm.Email = user.Email;
            vm.Mobile = user.Mobile;
            vm.NickName = user.NickName;
            vm.LoginToken = user.LoginToken;
            return vm;
        }

        /// <summary>
        /// 邮箱注册新用户，邮箱已自动转小写，账号已存在时提示，返回标准json
        /// </summary>
        public static async Task<string> AddUserByEmail(string email, string pwd)
        {
            if (email.IsNullOrEmpty())
                return Code.FailJson("email不能为空");
            if (pwd.IsNullOrEmpty())
                return Code.FailJson("密码不能为空");
            email = email.Trim().ToLower(); //转小写
            pwd = pwd.Trim(); //去掉首尾空格

            try
            {
                using (var conn = Db.Conn())
                {
                    var sql = "select uid from user where email=@email" + Tool.SqlPage();
                    var uid = (await conn.QueryAsync<int>(sql, new { email = email })).FirstOrDefault();
                    if (uid > 0)
                        return Code.FailJson(email + "邮箱已注册，请直接登录");

                    var pwdHash = GetPwdHash(pwd); //密码+guid混淆后md5加密
                    sql = "insert into user (email, pwd) values (@email,@pwd)";
                    var amount = await conn.ExecuteAsync(sql, new { email = email, pwd = pwdHash });
                    return (amount > 0) ? Code.SuccessJson(amount) : Code.FailJson("注册用户失败");
                }
            }
            catch (Exception ex) { LogA.AppError("AddUserByEmail" + ex.ToString()); return Code.FailJson(ex.Message); }
        }

        /// <summary>
        /// 密码+guid混淆后md5加密，返回hash值
        /// </summary>    
        private static string GetPwdHash(string pwd)
        {
            if (pwd.IsNullOrEmpty())
                return "密码不能为空";
            return ToolA.Md5(pwd + Config.PwdGuid);
        }

        /// <summary>
        /// 用户退出登录状态，移除缓存，移除cookie，更新数据库loginToken值为新的随机guid，返回json
        /// </summary>
        public static async Task<string> Logout(string cookieValue)
        {
            if (cookieValue.IsNullOrEmpty())
                return Code.FailJson("用户未登录"); 
            try
            {
                var logintoken = cookieValue; //logintoken
                var newLoginToken = Guid.NewGuid().ToString(); //新的随机guid
                CacheA.Remove(logintoken); //移除缓存
                ToolA.RemoveCookie(Config.UserToken); //移除cookie
                using (var conn = Db.Conn())
                {
                    //更新数据库loginToken值为新的随机guid
                    var sql = "update user set logintoken=@newLoginToken where logintoken=@loginToken";
                    var amount = await conn.ExecuteAsync(sql, new { logintoken = logintoken, newLoginToken = newLoginToken});
                    if (amount > 0)
                        return Code.SuccessJson("退出成功");
                    return Code.FailJson("退出失败");
                }
            }
            catch (Exception ex) { LogA.AppError("Logout" + ex.ToString()); return Code.FailJson(ex.Message); }
        }

        /// <summary>
        /// 跳转到returnUrl，未指定时跳转到默认首页
        /// </summary>
        public static void RedirectToReturnUrl(string returnUrl)
        {
            if (returnUrl.IsNullOrEmpty())
                ToolA.Redirect(Config.RootUrl); //未指定时，跳转到默认首页
            else
                ToolA.Redirect(returnUrl);
        }

    }

}
