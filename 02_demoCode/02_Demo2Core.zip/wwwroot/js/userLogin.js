﻿
//用户登录
var a1 = new Vue({
    el: '#a1', //对应<div id="a1">中的id值a1
    data: {
        email: '', //对应v-model="email"输入框
        pwd: '', //对应v-model="pwd"输入框
        result: '', //返回值
        isErrorEmail: false, //是否显示邮箱输入错误，默认不显示
        tipErrorEmail: '', //邮箱输入错误提示文字
        isErrorPwd: false, //是否显示密码输入错误，默认不显示
        tipErrorPwd: '', //密码输入错误提示文字
    },
    methods: {
        //用户登录
        LoginByEmail: function () {
            var vm = this; //必须这样，后面的字段赋值才能在页面显示{{result}} 
            vm.blurEmail(); vm.blurPwd(); //验证输入框     
            if (vm.isErrorEmail == true || vm.isErrorPwd == true)
                return;
            //vue调用dnc后台登录接口，验证密码成功后，跳转到目标页
            apiLoginByEmail(vm.email, vm.pwd, '/home/demo1'); 
        },
        //验证邮箱输入框
        blurEmail: function () {
            var vm = this; vm.isErrorEmail = true;
            if (vm.email == '') { vm.tipErrorEmail = "请输入邮箱"; }
            else if (IsEmail(vm.email) == false) { vm.tipErrorEmail = "邮箱格式不正确"; }
            else { vm.isErrorEmail = false; }
        },
        //验证密码输入框
        blurPwd: function () {
            var vm = this; vm.isErrorPwd = true;
            if (vm.pwd == '') { vm.tipErrorPwd = "请输入密码"; }
            else { vm.isErrorPwd = false; }
        }
    }
});