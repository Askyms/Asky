using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using MySql.Data.MySqlClient;


using Asky;

namespace Asky
{
    public partial class Db
    {             
        #region MySql/MariaDB/TiDB
        public static MySqlConnection ConnMySql()
        {  
            var conn = new MySqlConnection(Config.MySqlConn);
            //测试结果：每次都会重新打开连接，不打开连接也能正常使用，但sql事务要求必须打开连接
            if (conn.State != ConnectionState.Open)
                conn.Open();
            return conn;
        }
        #endregion

        #region PostgreSQL
        //public static Npgsql.NpgsqlConnection ConnPostgreSQL()
        //{
        //    var conn = new Npgsql.NpgsqlConnection(Db.PostgreSQLConnectString);
        //    //测试结果：每次都会重新打开连接，不打开连接也能正常使用，但sql事务要求必须打开连接
        //    if (conn.State != ConnectionState.Open)
        //        conn.Open();
        //    return conn;
        //}
        #endregion

        #region Sql Server        
        #endregion

        #region 切换数据库
        /// <summary>
        /// 通用Conn，可切换数据库TiDB、MySql、PostgreSql
        /// sql语句完全兼容
        /// </summary>     
        //public static Npgsql.NpgsqlConnection Conn()
        public static MySqlConnection Conn()
        {
            //return ConnPostgreSQL();
            return ConnMySql();
        } 
        #endregion
    }
}
