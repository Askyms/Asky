using Newtonsoft.Json;
using System;
using Asky;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Asky
{
    /// <summary>
    /// .NET 4.7.x与.NET Core 2.x 不一致的代码，写在A2.cs中
    /// </summary>
    public class A2
    {
        /// <summary>
        /// 换行符，dnc 2.x用Environment.NewLine，.net 4.7.x用《br/》
        /// </summary>
        public static  string Br()
        {
            return Environment.NewLine;
            //return "<br/>";
        }

    }
}