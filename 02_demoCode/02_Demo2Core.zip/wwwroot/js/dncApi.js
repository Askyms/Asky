﻿
//vue调用dnc后台接口，新用户注册，方法名加api前缀
function apiAddUserByEmail(email, pwd, returnUrl) {
    if (email == '' || pwd == '') { alert('email、密码不能为空'); return; }
    var params = new URLSearchParams();
    params.append('email', email);
    params.append('pwd', pwd);
    axios.post('/User/AddUserByEmail', params) //axios是一个js工具类库，用于调用后台接口
        .then(function (response) {
            var result = response.data;  //返回值
            if (result != null) {
                if (result.status == 1)   //alert("注册成功");                   
                    apiLoginByEmail(email, pwd, returnUrl); //自动登录并跳转到目标页
                else
                    alert(result.msg);
            }
        }).catch(function (error) { console.log("【操作失败】" + error); });
}


//vue调用dnc后台接口，用户登录，方法名加api前缀
function apiLoginByEmail(email, pwd, returnUrl) {
    if (email == '' || pwd == '') { alert('email、密码不能为空'); return; }
    var params = new URLSearchParams();
    params.append('email', email);
    params.append('pwd', pwd);
    axios.post('/User/LoginByEmail', params)
        .then(function (response) {
            var result = response.data;  //返回值
            if (result != null) {
                if (result.status == 1)
                    location.href = returnUrl; //登录成功，跳转到目标页
                else
                    alert(result.msg);
            }
        }).catch(function (error) { console.log("【操作失败】" + error); });
}