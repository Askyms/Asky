﻿
//新用户注册
var a1 = new Vue({
    el: '#a1', //对应<div id="a1">中的id值a1
    data: {
        email: '', //对应v-model="email"输入框
        pwd: '', //对应v-model="pwd"输入框
        pwd2: '', //对应v-model="pwd2"输入框
        result: '', //返回值
        isErrorEmail: false, //是否显示邮箱输入错误，默认不显示
        tipErrorEmail: '', //邮箱输入错误提示文字
        isErrorPwd: false, //是否显示密码输入错误，默认不显示
        tipErrorPwd: '', //密码输入错误提示文字
        isErrorPwd2: false, //是否显示密码输入错误，默认不显示
        tipErrorPwd2: '', //密码输入错误提示文字
    },
    methods: {
        //新用户注册
        addUserByEmail: function () {
            var vm = this; //必须这样，后面的字段赋值才能在页面显示{{result}}            
            vm.blurEmail(); vm.blurPwd(); vm.blurPwd2();  //验证输入框
            if (vm.isErrorEmail == true || vm.isErrorPwd == true || vm.isErrorPwd2 == true)
                return;
            apiAddUserByEmail(vm.email, vm.pwd, '/home/demo1');//vue调用dnc后台接口
        },
        //验证邮箱输入框
        blurEmail: function () {
            var vm = this; vm.isErrorEmail = true;
            if (vm.email == '') { vm.tipErrorEmail = "请输入邮箱"; }
            else if (IsEmail(vm.email) == false) { vm.tipErrorEmail = "邮箱格式不正确"; }
            else { vm.isErrorEmail = false; }
        },
        //验证密码输入框
        blurPwd: function () {
            var vm = this; vm.isErrorPwd = true;
            if (vm.pwd == '') { vm.tipErrorPwd = "请输入密码"; }
            else if (vm.pwd.length < 6) { vm.tipErrorPwd = "密码必须6个字符以上"; }
            else { vm.isErrorPwd = false; }
        },
        //验证确认密码输入框
        blurPwd2: function () {
            var vm = this; vm.isErrorPwd2 = true;
            if (vm.pwd2 == '') { vm.tipErrorPwd2 = "请输入密码"; }
            else if (vm.pwd != vm.pwd2) { vm.tipErrorPwd2 = "两次输入的密码不一致"; }
            else { vm.isErrorPwd2 = false; }
        }

    }
});


