using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Dapper;
using System.Linq;

using System.Threading;



using Asky;

namespace Asky
{
    /// <summary>
    /// 定时任务
    /// </summary>
    public class TimeTaskBll
    {
        #region 多线程开启多个任务，每个线程开启一个任务
        /// <summary>
        /// 多线程开启多个任务，每个线程开启一个任务
        /// </summary>
        public static string EverySchoolDataSyncTask()
        {
            //以后修改到数据库配置节点中，n个城市对应连接串
            //for (int i = 0; i < length; i++)
            {
                Task.Run(() => TaskMinute("bj_DataSyncTaskMinute")); //北京
                Task.Run(() => TaskMinute("sh_DataSyncTaskMinute")); //上海
                Task.Run(() => TaskMinute("gz_DataSyncTaskMinute")); //广州
            }
            return Code.SuccessText;
        }
        #endregion

        #region 定时任务，每N分钟执行一次
        /// <summary>
        /// 每天执行一次任务的上次执行时间
        /// </summary>
        //private static DateTime LastTaskDayTime = new DateTime(1800, 1, 1);

        /// <summary>
        /// 定时任务，每N分钟执行一次
        /// </summary>
        public static string TaskMinute(string taskCacheKey)
        {
            while (true)
            {
                try
                {
                    #region 任务
                    var isDevTest = Config.TimeTaskMinuteRunNowTest; //是否立即执行，用于开发测试，正式上线前必须修改为false
                    var cache = CacheA.Get(taskCacheKey);
                    if (cache != null && cache.ToStringX3() == "1")
                    {
                        LogA.TMTask(ToolA.GetThreadId() + "每N分钟任务，跳过本次任务");
                        //return "跳过本次任务";//不能用return，因为它会跳出while循环
                        continue; //应该用continue
                    }

                    if (isDevTest || cache.ToStringX3() != "1")
                    {
                        //开始执行前，设置缓存开关，防止上一个任务正在执行时，重复执行下一次任务
                        CacheA.Set(taskCacheKey, "1", Config.TimeTaskMinute);
                        //CacheA.SetSecond(taskCacheKey, "1", 15); //间隔15秒，用于快速测试

                        LogA.TMTask(ToolA.GetThreadId() + "每N分钟任务，开始执行");
                        //var taskResult = DemoBll.Demo1(); //调用实际的任务方法
                        var taskResult = "demo1成功";
                        LogA.TMTask(ToolA.GetThreadId() + "每N分钟任务，执行结果：" + taskResult);
                    }
                    #endregion
                }
                catch (Exception ex) { LogA.AppError(ex.ToString()); }
                finally { Thread.Sleep(10_000); } //每10秒循环
            }
        }
        #endregion

        #region 定时任务，每天执行一次
        /// <summary>
        /// 每天执行一次任务的上次执行时间
        /// </summary>
        private static DateTime LastTaskDayTime = new DateTime(1800, 1, 1);

        /// <summary>
        /// 每天执行一次的任务
        /// </summary>
        public static string TaskDayOnce()
        {
            while (true)
            {
                try
                {
                    #region 任务
                    var isDevTest = Config.TimeTaskDayOnceRunNowTest; //是否立即执行，用于开发测试，正式上线前必须修改为false
                    var dayHour = Config.TimeTaskDayOnceHour; //每天几点执行任务
                    if (isDevTest || (DateTime.Now.Hour == dayHour))
                    {
                        if ((DateTime.Now - LastTaskDayTime).TotalHours > 20) //每天执行一次
                        {
                            LogA.TMTask(ToolA.GetThreadId() + "定时任务：每天" + dayHour + "点执行一次");
                            LastTaskDayTime = DateTime.Now; //防止重复执行
                            //var taskResult = DemoBll.Demo1(); //调用实际的任务方法
                            var taskResult = "demo1成功";
                            LogA.TMTask(ToolA.GetThreadId() + "执行结果：" + taskResult);
                        }
                    }
                    #endregion
                }
                catch (Exception ex) { LogA.AppError(ex.ToString()); }
                finally { Thread.Sleep(10_000); } //每10秒循环
            }
        }
        #endregion

    }

}
