using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Asky;

namespace Asky
{
    public class HomeController : Controller
    {        

        public async Task<string> Index()   
        {
            //return await Task.FromResult("dnc 2.x");

            //.NET 4.7.x与.NET Core 2.x 不一致的代码 写在A2中，调用方法相同，例如A2.Br()
            var result = A.demo1 + A2.Br();
             result += "【0】A.GetRootPath()当前项目：" + A.GetRootPath() + A2.Br();

            //【1】a.config配置节点
            result += "【1】a.config配置节点Config.LogPath：" + Config.LogPath + A2.Br();

            //【2】读写cookie，设置cookie后，需要页面跳转或刷新才能读取出cookie值
            ToolA.SetCookie("ck1", "ck1cookie值"); 
            var cookieValue = ToolA.GetCookie("ck1");
            result += "【2】读写cookie值：" + cookieValue + A2.Br();

            //【3】读写本地缓存        
            CacheA.Set("k1", "k1缓存值"); //写缓存
            var cacheValue = CacheA.Get("k1"); //读缓存 
            result += "【3】读写本地缓存值：" + cacheValue + A2.Br();

            var vm = new { id = 1, email = "Asky@demo.com" };
            var json = vm.ToJson();
            var email = json.FromJsonTo<dynamic>().email;

            result += "【4】api接口" + "/home/demo1?id=1&name=测试" + A2.Br();

            result += "【5】vue+dnc示例" + "/vue3.htm" + A2.Br();

            return  result;
        }


        // /home/demo1?id=1&name=%E6%BC%94%E7%A4%BA
        public async Task<string> Demo1(string id, string name)
        {
            var result = await Task.FromResult("test");
            return "Api接口返回值【id】" + id + "【name】" + name;
        }

     
        // /home/AddProduct?productName=%E6%96%B01
        public async Task<string> AddProduct(string productName)
        {
            if (productName.IsNullOrEmpty())
                return "productName不能为空";

            return await ProductBll.AddProduct(productName);
        } 

        // /home/GetProductList?pageIndex=1&pageSize=5
        public async Task<string> GetProductList(int pageIndex, int pageSize)
        {
            return await ProductBll.GetProductList(pageIndex, pageSize);
        }  
          
        // /home/DeleteProduct?id=1
        public async Task<string> DeleteProduct(int id)
        {
            return await ProductBll.DeleteProduct(id);  
        }

        //加[HttpPost]限制后，只允许vue post，不能vue get，手动在浏览器也无法get访问
        //[HttpPost] //vue用post方式，这里可选 [HttpPost] 都可以
        // /home/UpdateProduct?id=1&productName=v1
        public async Task<string> UpdateProduct(int id, string productName)
        {
            return await ProductBll.UpdateProduct(id, productName);
        }


    }
}