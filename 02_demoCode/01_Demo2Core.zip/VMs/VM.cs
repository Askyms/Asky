﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Asky
{
    #region MySql、PostgreSql数据库表，可以复用VM，如果不用Dapper.Contrib插入，则dapper不需要指定表名，因为sql语句已指定
    //[Dapper.Contrib.Extensions.Table("user1")]
    //[Dapper.Contrib.Extensions.Table("public.user1")] //pg不需要这样写，直接user1即可
    public class User1
    {
        public int id { get; set; }
        public string name { get; set; }
    }

    //[Dapper.Contrib.Extensions.Table("AConfig")]
    public class AConfig
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public string Memo { get; set; }
    }

    //[Dapper.Contrib.Extensions.Table("AUser")]
    public class AUser
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string NickName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Pwd { get; set; }
        public DateTime CreateTime { get; set; }
        public int Status { get; set; }
        public int LoginAmount { get; set; }
        public DateTime LoginTime { get; set; }
    }

    public class UserModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
    }
    #endregion
}
  