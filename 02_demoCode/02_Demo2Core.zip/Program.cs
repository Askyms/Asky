﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Asky
{
    public class Program
    {
        public static void Main(string[] args)
        {  
            Task.Run(() => TimeTaskBll.EverySchoolDataSyncTask()); //每N分钟执行一次，异步执行定时任务，必须放在BuildWebHost(args).Run(); 前面才会执行
            Task.Run(() => TimeTaskBll.TaskDayOnce()); //每天执行一次，异步执行定时任务，必须放在BuildWebHost(args).Run(); 前面才会执行
            BuildWebHost(args).Run();
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .Build();
    }
}
