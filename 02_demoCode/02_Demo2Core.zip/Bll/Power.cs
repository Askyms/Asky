using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Dapper;
using System.Linq;


using Asky;

namespace Asky
{
    public class Power
    {
       
        /// <summary>
        /// 权限判断，先判断用户登录状态，再判断是否有权限
        /// </summary>
        public static Result HasPower(ERole role)
        {
            var currentUser = UserBll.CurrentUser;
            if (currentUser == null)
                return Code.Fail("用户未登录");

            if (role == ERole.Vip)
                return Code.Success(); //有权限

            return Code.Fail("无权限");
        }


    }

}
