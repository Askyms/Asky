using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Asky;

namespace Asky
{
    /// <summary>
    /// dnc 2.x、.NET 4.7.x 通用
    /// </summary>
    public partial class Tool
    {
        #region Sql
        /// <summary>
        /// 返回值包含一个起始空格，分页Sql方便切换数据库TiDB、MySql、PostgreSql，
        /// 兼容TiDB、MySql、postgreSQL分页语句limit 2 offset 1
        /// </summary>
        public static string SqlPage(int pageIndex, int pageSize)
        {
            return $" limit {pageSize} offset {(pageIndex - 1) * pageSize}";
        }
        #endregion
    }
}
